package com.capgemini.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author KMURLIDH
 * 
 *  Domain Class for Sentence
 */
public class Sentence {

	String sentenceNumber;
	List<String> words=new ArrayList();
	
	public String getSentenceNumber() {
		return sentenceNumber;
	}
	public void setSentenceNumber(String sentenceNumber) {
		this.sentenceNumber = sentenceNumber;
	}
	public List<String> getWords() {
		return words;
	}
	public void setWords(List<String> words) {
		this.words = words;
	}
	public Sentence(String sentenceNumber, List<String> words) {
		super();
		this.sentenceNumber = sentenceNumber;
		this.words = words;
	}
	
	
	
}
