package com.capgemini;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.capgemini.exception.FileParserException;
import com.capgemini.service.FileParserService;
import com.capgemini.service.impl.FileParserServiceImpl;
import com.capgemini.util.FileParserUtil;

/**
 * @author KMURLIDH This is class to run WordsParser applications
 **/

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		 SpringApplication.run(DemoApplication.class, args);
		// creating FileParserService 
		 
		 try {
		FileParserService service = new FileParserServiceImpl();
		
		//getting command line arguments
		String inputFilePath = args[0];
		String outputFilePath = args[1];
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please select ouptput file type");
		System.out.println("Enter 0 for CSV Format");
		System.out.println("Enter 1 for XML format");
		
		int choice = scanner.nextInt();
		String outputFileFormat = null;

		switch (choice) {
		case 0:
			outputFileFormat = FileParserUtil.CSVFORMAT;
			break;
		case 1:
			outputFileFormat = FileParserUtil.XMLFORMAT;
			break;
		default:
			System.out.println("Invalid choice entered!");
			break;
		}
		//calling parseFileContent()
		
			service.parseFileContent(inputFilePath, outputFilePath, outputFileFormat);
		} catch (FileParserException e) {
			// TODO Auto-generated catch block
			 System.out.println("FileParserException occured: "+e.getMessage());
		}
		 catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
