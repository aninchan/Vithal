package com.capgemini.service;

import java.util.List;

import com.capgemini.exception.FileParserException;
import com.capgemini.model.Sentence;
/*
 * FileParserService Interface list all neccessary service methods of WordsParser API
 */
public interface FileParserService {

	public void parseFileContent(String inputFilePath,String outputFilePath,String outputFileFormat) throws FileParserException;

	List<String> getSentences(List<String> lines);
	
	List<String> specialCharacterRemoval(List<String> sentences);
	
	public List<Sentence> getWords(List<String> sentences);
	
	public void getOutputInCSV(List<Sentence> sentenceList,String outputFilePath);
	
	public void getOutputInXML(List<Sentence> sentenceList,String outputFilePath);
	
	
}
