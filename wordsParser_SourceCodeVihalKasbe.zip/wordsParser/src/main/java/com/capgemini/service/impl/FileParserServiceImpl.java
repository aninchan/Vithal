package com.capgemini.service.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capgemini.exception.FileParserException;
import com.capgemini.model.Sentence;
import com.capgemini.service.FileParserService;
import com.capgemini.util.FileParserUtil;

/**
 * @author KMURLIDH.
 * 
 *         FileParserService provides functionality for breaking the file
 *         contents into lines. Once file is broken into lines then it will
 *         create individual sentences. Lastly It will break the sentences into
 *         the words. FileParserService also provides functionality to create
 *         ouptut CSV files of these Sentences' and words.
 */

public class FileParserServiceImpl implements FileParserService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FileParserServiceImpl.class);
	public final static String REGULAR_EXPRESSION = "(?<!\\w\\.\\w.)(?<![A-Z][a-z]\\.)(?<=\\.|\\?)\\s";
	String header = " ";

	/*
	 * This method is responsible to read the input file contents It also calls all
	 * necessary methods to create sentences,words and output files
	 * 
	 */
	@Override
	public void parseFileContent(String inputFile,String outputFilePath,String outputFileFormat) throws FileParserException {
		// TODO Auto-generated method stub
		LOGGER.info("Inside of parseFileContent()");
		try {
			//Reading file contents
			if(inputFile.trim().isEmpty())
			{
				throw new FileParserException("Input file path is empty!");
			}
			if(outputFilePath.trim().isEmpty())
			{
				throw new FileParserException("Output file path is empty!");
			}
			List<String> lines = Files.readAllLines(Paths.get(inputFile));
			List<String> sentences = getSentences(lines);
			sentences = specialCharacterRemoval(sentences);
			List<Sentence> listOfSentences = getWords(sentences);
			if(outputFileFormat.equals(FileParserUtil.CSVFORMAT))
			{
			getOutputInCSV(listOfSentences,outputFilePath);
			}
			else if(outputFileFormat.equals(FileParserUtil.XMLFORMAT))
			{
			getOutputInXML(listOfSentences,outputFilePath);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Exception occurred while processing file in parseFileContent");
			System.out.println("Exception occurred while processing file: " + e.getMessage());
		}

	}

	/*
	 * This method is responsible to break the file contents into lines. Further, it
	 * will break the lines into senetences and returns list of sentences.
	 * 
	 */
	public List<String> getSentences(List<String> lines) {
		LOGGER.info("Inside of getSentences()");
		List<String> formattedLines = new ArrayList<String>();
		List<String> formattedSentence = new ArrayList<String>();
		List<String> finalSentences = new ArrayList<String>();
		String emptyChar = "";
		for (String line : lines) {
			String sentenceArray[] = line.split(REGULAR_EXPRESSION);
			for (String sentence : sentenceArray) {
				formattedLines.add(sentence);
			}
		}
		for (String line : formattedLines) {

			if (!line.trim().isEmpty()) {
				if (!emptyChar.trim().isEmpty()) {
					line = emptyChar + line;
					emptyChar = "";
				}

				if (!(line.endsWith(".") || line.endsWith("!") || line.endsWith("?"))) {
					emptyChar = line;
				} else {
					formattedSentence.add(line);
				}
			}
		}

		for (String line : formattedSentence) {
			String[] sentences = line.split("!");
			for (String sentence : sentences) {
				finalSentences.add(sentence);
			}
		}

		return finalSentences;
	}

	/*
	 * This method is responsible for removing special characters from the
	 * sentences.
	 * 
	 */
	public List<String> specialCharacterRemoval(List<String> sentences) {
		LOGGER.info("Inside of specialCharacterRemoval()");
		List<String> newSentenceList = new ArrayList<String>();
		for (int i = 0; i < sentences.size(); i++) {
			if (i != 0) {
				newSentenceList.add(sentences.get(i).substring(0, sentences.get(i).length() - 1));
			} else {
				newSentenceList.add(sentences.get(i).trim());
			}
		}

		newSentenceList = newSentenceList.stream().map(line -> {
			line = line.trim();
			line = line.replace(",", " ");
			line = line.replace("  ", " ");
			line = line.replace(":", "");
			line = line.replace("(", "");
			line = line.replace(" - ", " ");
			line = line.replace(")", "");
			line = line.replace("\t", " ");
			line = line.replace("\\s", " ");

			return line;

		}).collect(Collectors.toList());

		return newSentenceList;
	}

	/*
	 * This method gets words from sentences It returns words into list of sentences
	 * 
	 */
	public List<Sentence> getWords(List<String> sentences) {
		LOGGER.info("Inside of getWords()");
		List<Sentence> listOfSentences = new ArrayList<Sentence>();
		int sentenceNumber = 1;
		for (String sentence : sentences) {
			List<String> wordsList = new ArrayList<String>();
			String[] words = sentence.split(" ");
			for (String word : words) {
				if (word.length() != 0)
					wordsList.add(word.trim());
			}
			wordsList = wordsList.stream().sorted((w1, w2) -> w1.compareToIgnoreCase(w2)).collect(Collectors.toList());

			listOfSentences.add(new Sentence("Sentence " + sentenceNumber, wordsList));

			sentenceNumber++;
		}
		return listOfSentences;

	}

	/*
	 * This method is to generate output in CSV file format
	 * 
	 */
	public void getOutputInCSV(List<Sentence> sentenceList,String outputFilePath) {

		LOGGER.info("Inside of getOutputInCSV()");
		try {

			FileWriter fileWriter = new FileWriter(new File(outputFilePath+"/output.csv"));
			BufferedWriter writer = new BufferedWriter(fileWriter);

			IntStream stream = IntStream.range(1, 40);
			stream.forEach(i -> {
				header = header + "," + "Word " + i;
			});

			writer.write(header);
			writer.newLine();
			sentenceList.forEach(sentence -> {
				String sentenceNumber = sentence.getSentenceNumber();
				String words = sentence.getWords().stream().collect(Collectors.joining(","));
				try {
					writer.write(sentenceNumber + "," + words);
					writer.newLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					LOGGER.error("Error generating CSV output files in getOutputInCSV()");
					System.out.println("Error occurred while creating CSV file " + e.getMessage());
				}

			});

			writer.flush();
			writer.close();
			fileWriter.close();
		
		} catch (

		IOException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error occurred while creating output CSV files " + e.getMessage());
			System.out.println("Error occurred while creating CSV file " + e.getMessage());
		}
		System.out.println("Successfully generated CSV Output file in  "+outputFilePath);
	}

	/*
	 * This method is to generate output in XML file format
	 * 
	 */
	@Override
	public void getOutputInXML(List<Sentence> sentenceList,String outputFilePath) {
		// TODO Auto-generated method stub
		LOGGER.info("Inside of getOutputInXML()");
		FileWriter fileWriter;
		try {
			fileWriter = new FileWriter(new File(outputFilePath+"/output.xml"));
			BufferedWriter writer = new BufferedWriter(fileWriter);
			writer.write("<text>");
			writer.newLine();
			sentenceList.forEach(sentence -> {
				try {
					writer.write("<sentence>");
					writer.newLine();
					List<String> words = sentence.getWords();
					words.forEach(word -> {
						try {
							writer.write("<word>");
							writer.write(word);
							writer.write("</word>");
							writer.newLine();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					});
					writer.write("</sentence>");
					writer.newLine();

				} catch (IOException e) {
					e.printStackTrace();
				}
			});

			writer.write("</text>");
			writer.flush();
			writer.close();
			fileWriter.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error occurred while generating XML file");
			System.out.println("Error occurred while generating XML file "+e.getMessage());
		}
		System.out.println("Successfully generated XML Output file in  "+outputFilePath);
	}

}
