package com.capgemini.util;

public class FileParserUtil {

	public static final String XMLFORMAT="XML";
	public static final String CSVFORMAT="CSV";
}
