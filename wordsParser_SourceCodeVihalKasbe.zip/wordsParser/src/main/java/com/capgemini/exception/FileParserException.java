package com.capgemini.exception;

public class FileParserException extends Exception{

	public FileParserException()
	{
		super();
	}
	
	public FileParserException(String exceptionMessage)
	{
		super(exceptionMessage);
	}
}
