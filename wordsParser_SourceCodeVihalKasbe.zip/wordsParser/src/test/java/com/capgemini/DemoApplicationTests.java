package com.capgemini;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.service.impl.FileParserServiceImpl;
import com.capgemini.util.FileParserUtil;

@SpringBootTest
class DemoApplicationTests {

	@Test
	void testService() 
	{
		FileParserServiceImpl service=new FileParserServiceImpl();
		try
		{
			service.parseFileContent("C:\\Nordea\\File Parser\\Input files\\small.in","C:\\Nordea\\File Parser\\Output files" ,FileParserUtil.CSVFORMAT);
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
